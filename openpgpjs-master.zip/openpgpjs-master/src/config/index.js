/**
 * @fileoverview This object contains global configuration values.
 * @see module:config/config
 * @module config
 */

export { default } from './config.js';
