describe('Web Worker', function () {
  require('./async_proxy.js');
});

